/* ===== everydive.id x BAC — Script (GOLDEN TROPIC) =====
   Fitur: tema, menu, indikator kedalaman, reveal, parallax, count-up,
   gelembung hero, disiplin, kalkulator, galeri, form gabung.
   Data gear & WhatsApp admin ada di js/catalog-data.js. */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Konfigurasi (GANTI) ---------- */
  // Nomor WhatsApp admin diatur di js/catalog-data.js
  var WA_NUMBER = (function () {
    var n = String((window.FUNDIVE && window.FUNDIVE.wa) || '').replace(/\D/g, '');
    return n.charAt(0) === '0' ? '62' + n.slice(1) : n;
  })();
  var THEME_COLOR = { light: '#FAF6EE', dark: '#071E33' };

  /* ---------- Tema ---------- */
  var root = document.documentElement;
  // Warna bar status HP (Android Chrome / iOS Safari) ikut tema
  function setThemeColor(t) {
    var m = $('meta[name="theme-color"]');
    if (m) m.setAttribute('content', THEME_COLOR[t] || THEME_COLOR.light);
  }
  try { var saved = localStorage.getItem('theme'); if (saved) { root.setAttribute('data-theme', saved); setThemeColor(saved); } } catch (e) {}
  $('#themeBtn').addEventListener('click', function () {
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    setThemeColor(next);
    try { localStorage.setItem('theme', next); } catch (e) {}
  });

  /* ---------- Service worker (hanya di https/localhost) ---------- */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  /* ---------- Menu mobile (lembar layar penuh) ---------- */
  var burger = $('#burger'), menu = $('#menu');
  function setMenu(open) {
    menu.classList.toggle('open', open);
    document.body.classList.toggle('no-scroll', open);
    burger.setAttribute('aria-expanded', open);
    burger.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
  }
  burger.addEventListener('click', function () { setMenu(!menu.classList.contains('open')); });
  $$('a', menu).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
  window.addEventListener('resize', function () { if (window.innerWidth >= 960) setMenu(false); });

  /* ---------- Indikator kedalaman + tab aktif ---------- */
  var fill = $('#depthFill'), num = $('#depthNum'), nav = $('#nav');
  var tabs = $$('.tabbar a');
  var tabIds = tabs.map(function (a) { return a.getAttribute('href').slice(1); });
  function setActiveTab() {
    var cur = tabIds[0], y = window.innerHeight * 0.4;
    tabIds.forEach(function (id) {
      var el = document.getElementById(id);
      if (el && el.getBoundingClientRect().top <= y) cur = id;
    });
    tabs.forEach(function (a) {
      var on = a.getAttribute('href') === '#' + cur;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
    });
  }
  var ticking = false, lastY = 0, wa = $('.wa-float');
  function update() {
    ticking = false;
    var y = window.scrollY;
    if (wa) {
      if (y > lastY + 6 && y > 200) wa.classList.add('hide');
      else if (y < lastY - 6 || y <= 200) wa.classList.remove('hide');
    }
    lastY = y;
    var max = document.documentElement.scrollHeight - window.innerHeight;
    var p = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
    fill.style.height = (p * 100) + '%';
    num.textContent = Math.round(p * 30); // 0 - 30 m
    nav.style.setProperty('--p', p.toFixed(4)); // garis progres di navbar (HP)
    setActiveTab();
  }
  function onScroll() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
  window.addEventListener('scroll', onScroll, { passive: true });
  update();

  /* ---------- Reveal on scroll ---------- */
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    $$('.reveal').forEach(function (el) { io.observe(el); });
  } else { $$('.reveal').forEach(function (el) { el.classList.add('in'); }); }

  /* ---------- Count-up statistik ---------- */
  function animateCount(el) {
    var target = parseFloat(el.getAttribute('data-target')) || 0;
    var suffix = el.getAttribute('data-suffix') || '';
    var t0 = null, dur = 1300;
    function step(ts) {
      if (!t0) t0 = ts;
      var p = Math.min(1, (ts - t0) / dur);
      var eased = 1 - Math.pow(1 - p, 3); // easeOutCubic
      el.textContent = Math.round(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  var counters = $$('.count');
  if ('IntersectionObserver' in window && !reduce && counters.length) {
    var cio = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        cio.unobserve(e.target);
        animateCount(e.target);
      });
    }, { threshold: 0.6 });
    counters.forEach(function (c) { cio.observe(c); });
  }

  /* ---------- Parallax hero (scroll + gerak mouse di desktop) ---------- */
  var heroEl = $('.hero');
  var pxEls = $$('[data-speed]');
  var fine = window.matchMedia('(pointer: fine)').matches;
  if (!reduce && pxEls.length) {
    var pxMX = 0, pxMY = 0, pxQueued = false;
    function pxApply() {
      pxQueued = false;
      var y = window.scrollY;
      for (var i = 0; i < pxEls.length; i++) {
        var el = pxEls[i];
        var s = parseFloat(el.getAttribute('data-speed')) || 0;
        var ty = y * s * -0.22 + pxMY * s * -10;
        var tx = pxMX * s * -14;
        el.style.transform = 'translate3d(' + tx.toFixed(1) + 'px,' + ty.toFixed(1) + 'px,0)';
      }
    }
    function pxQueue() { if (!pxQueued) { pxQueued = true; requestAnimationFrame(pxApply); } }
    window.addEventListener('scroll', pxQueue, { passive: true });
    if (fine && heroEl) {
      heroEl.addEventListener('mousemove', function (e) {
        pxMX = (e.clientX / window.innerWidth - 0.5) * 2;
        pxMY = (e.clientY / Math.max(1, heroEl.offsetHeight) - 0.5) * 2;
        pxQueue();
      });
      heroEl.addEventListener('mouseleave', function () { pxMX = 0; pxMY = 0; pxQueue(); });
    }
    pxApply();
  }
  // Bar kedalaman di kartu hero terisi saat halaman siap (juga untuk reduced-motion)
  setTimeout(function () { var b = $('#hcBar'); if (b) b.style.width = '78%'; }, 700);

  /* ---------- Gelembung di hero (warna ikut tema) ---------- */
  var cv = $('#bubbles');
  if (cv && !reduce) {
    var ctx = cv.getContext('2d'), bubbles = [], W, H;
    var lastW = 0, visible = true;
    function size() { W = cv.width = cv.offsetWidth; H = cv.height = cv.offsetHeight; lastW = window.innerWidth; }
    size();
    // Resize hanya jika lebarnya berubah (address bar HP naik-turun tidak mereset kanvas)
    window.addEventListener('resize', function () { if (window.innerWidth !== lastW) size(); });
    // Hemat baterai: berhenti menggambar saat hero tidak terlihat
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { visible = es[0].isIntersecting; }, { threshold: 0 }).observe(cv);
    }
    var COUNT = window.innerWidth < 760 ? 16 : 30;
    for (var i = 0; i < COUNT; i++) {
      bubbles.push({
        x: Math.random(), y: Math.random(), r: 2 + Math.random() * 6,
        s: 0.0006 + Math.random() * 0.0012, d: Math.random() * 6,
        v: Math.random() > 0.45 ? 0 : 1 // 0 = emas, 1 = laut
      });
    }
    var BUBBLE = {
      light: { stroke: ['rgba(198,149,47,.50)', 'rgba(14,107,168,.40)'], fill: ['rgba(198,149,47,.08)', 'rgba(14,107,168,.07)'] },
      dark: { stroke: ['rgba(229,188,93,.45)', 'rgba(111,187,238,.35)'], fill: ['rgba(229,188,93,.07)', 'rgba(111,187,238,.08)'] }
    };
    (function loop(t) {
      if (!visible || document.hidden) { requestAnimationFrame(loop); return; }
      ctx.clearRect(0, 0, W, H);
      var c = BUBBLE[root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'];
      bubbles.forEach(function (b) {
        b.y -= b.s * 16; if (b.y < -0.05) { b.y = 1.05; b.x = Math.random(); }
        var x = b.x * W + Math.sin(t / 900 + b.d) * 12, y = b.y * H;
        ctx.beginPath(); ctx.arc(x, y, b.r, 0, 6.283);
        ctx.strokeStyle = c.stroke[b.v]; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.fillStyle = c.fill[b.v]; ctx.fill();
      });
      requestAnimationFrame(loop);
    })(0);
  }

  /* ---------- DISIPLIN FREEDIVE ---------- */
  var disciplines = [
    { code: 'STA', name: 'Static Apnea', desc: 'Menahan napas selama mungkin dalam posisi diam, biasanya mengapung di kolam dengan wajah di air. Latihan paling dasar untuk relaksasi dan toleransi CO2. Wajib ada pengawas.' },
    { code: 'DYN', name: 'Dynamic with Fins', desc: 'Berenang horizontal sejauh mungkin di bawah air memakai fins (monofin atau bifins), dalam satu tarikan napas.' },
    { code: 'DNF', name: 'Dynamic No Fins', desc: 'Berenang horizontal tanpa fins, hanya dengan gaya dada khusus. Menuntut teknik dan efisiensi gerak.' },
    { code: 'CWT', name: 'Constant Weight', desc: 'Turun dan naik di sepanjang tali dengan tenaga sendiri memakai fins atau monofin, tanpa mengubah beban.' },
    { code: 'FIM', name: 'Free Immersion', desc: 'Turun dan naik dengan menarik tali tanpa fins. Cara bagus untuk melatih equalization dan relaksasi.' },
    { code: 'CNF', name: 'Constant No Fins', desc: 'Turun dan naik di sepanjang tali tanpa fins dan tanpa menarik tali. Salah satu disiplin tersulit.' },
    { code: 'VWT', name: 'Variable Weight', desc: 'Turun memakai pemberat (sled) dan naik dengan tenaga sendiri. Disiplin lanjutan yang butuh pengalaman dan tim pengawas.' },
    { code: 'NLT', name: 'No Limits', desc: 'Turun dengan sled dan naik dengan balon atau alat bantu. Disiplin ekstrem untuk atlet berpengalaman, bukan untuk pemula.' }
  ];
  var dGrid = $('#disciplines'), dModal = $('#discModal');
  disciplines.forEach(function (d, i) {
    var b = document.createElement('button');
    b.className = 'card disc reveal in'; b.type = 'button';
    b.style.setProperty('--d', (i % 4) * 0.06 + 's');
    b.innerHTML = '<strong>' + d.code + '</strong><span>' + d.name + '</span>';
    b.addEventListener('click', function () {
      $('#dmTitle').textContent = d.code + ' — ' + d.name;
      $('#dmBody').textContent = d.desc;
      if (typeof dModal.showModal === 'function') dModal.showModal(); else dModal.setAttribute('open', '');
    });
    dGrid.appendChild(b);
  });
  $('#dmClose').addEventListener('click', function () { dModal.close ? dModal.close() : dModal.removeAttribute('open'); });
  dModal.addEventListener('click', function (e) { if (e.target === dModal) dModal.close ? dModal.close() : dModal.removeAttribute('open'); });

  /* ---------- Kalkulator wetsuit & pemberat (estimasi awal) ---------- */
  $('#calcForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var h = +$('#cH').value, w = +$('#cW').value, t = +$('#cT').value;
    var size = w < 50 ? 'S' : w < 62 ? 'M' : w < 75 ? 'L' : w < 90 ? 'XL' : 'XXL';
    if (h >= 180 && size !== 'XXL') size += ' (tall)';
    var f = { 0: 0.01, 1.5: 0.025, 3: 0.035, 5: 0.05 }[t];
    var kg = w * f;
    var lo = Math.max(0, kg - 0.5).toFixed(1), hi = (kg + 0.5).toFixed(1);
    $('#calcOut').textContent = 'Estimasi ukuran wetsuit: ' + size + '. Estimasi awal pemberat: ' + lo + ' - ' + hi + ' kg.';
  });

  /* ---------- Lightbox galeri ---------- */
  var lb = $('#lightbox');
  $$('#gallery button').forEach(function (b) {
    b.addEventListener('click', function () { $('#lbCap').textContent = b.dataset.cap; if (typeof lb.showModal === 'function') lb.showModal(); else lb.setAttribute('open', ''); });
  });
  $('#lbClose').addEventListener('click', function () { lb.close ? lb.close() : lb.removeAttribute('open'); });
  lb.addEventListener('click', function (e) { if (e.target === lb) lb.close ? lb.close() : lb.removeAttribute('open'); });

  /* ---------- Form gabung -> WhatsApp ---------- */
  $('#joinForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var n = $('#fName').value.trim(), a = $('#fAge').value, x = $('#fExp').value, w = $('#fWa').value.trim();
    var msg = $('#formMsg');
    if (!n || !a || !x || !/^[0-9+\s-]{9,16}$/.test(w)) { msg.textContent = 'Lengkapi semua kolom dengan benar ya.'; return; }
    if (!/^62\d{8,13}$/.test(WA_NUMBER)) { msg.textContent = 'Nomor WhatsApp admin belum diatur di js/catalog-data.js.'; return; }
    var text = 'Halo BAC! Saya mau gabung.\nNama: ' + n + '\nUsia: ' + a + '\nPengalaman: ' + x + '\nWA: ' + w;
    msg.textContent = 'Membuka WhatsApp...';
    window.open('https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
  });
})();
